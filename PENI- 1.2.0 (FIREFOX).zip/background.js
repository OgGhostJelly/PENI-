browser.storage.local.set( {
        specialtxt: 'peni-',
        full: 0,
        img: 0,
    }
)