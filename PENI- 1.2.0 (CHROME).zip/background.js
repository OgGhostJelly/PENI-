chrome.storage.local.set( {
    specialtxt: 'peni-',
    full: 0,
    img: 0,
})
console.log('background')