chrome.storage.local.set( {
        specialtxt: 'peni-',
    }
)